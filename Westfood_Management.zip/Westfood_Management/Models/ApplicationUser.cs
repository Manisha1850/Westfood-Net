﻿using Microsoft.AspNetCore.Identity;

namespace Westfood_Management.Models
{
    public class ApplicationUser:IdentityUser
    {
        public string? Name { get; set; }

        public string? Address { get; set; }
    }
}
