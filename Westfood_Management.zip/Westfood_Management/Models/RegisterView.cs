﻿using System.ComponentModel.DataAnnotations;

namespace Westfood_Management.Models
{
    public class RegisterView
    {
        [Required]
        public string? Name { get; set; }
    
        [Required, EmailAddress]
        public string? Email { get; set; }

        [Required]
        public string? Hotel { get; set; }

        [Required]
        public string? Address { get; set; }

        [Required]
        public string? Password { get; set; }

        [Required]
        public int? Phone { get; set; }
    }
}
