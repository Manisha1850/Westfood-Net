﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Westfood_Management.Models;

namespace Westfood_Management.Controllers
{

   
    public class AccountController : Controller
    {

    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;

    public AccountController(UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager)
    {
        _userManager = userManager;
        _signInManager = signInManager;

    }
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]

        public async IActionResult Register([FromForm] RegisterView register)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser()
                {
                    Name=register.Name, Email=register.Email, Address=register.Address,
                    //Hotel = register.Hotel, Phone = register.Phone


                };
                var result = await _userManager.CreateAsync(user, register.Password);
                if(result.Succeeded)
                {
                    await _signInManager.PasswordSignInAsync(user, register.Password, false, false);

                }
                else
                {
                    foreach(var err in result.Errors)
                    {
                        ModelState.AddModelError("",err.Description);
                    }
                }

            }
            return View(register);
        }

    }
}
