﻿using Microsoft.AspNetCore.Mvc;

namespace Westfood_Management.Controllers
{
    public class Donations : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
